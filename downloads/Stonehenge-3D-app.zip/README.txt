Stonehenge in 3D – offline web app
By Michael H. Grant, mhgfysik.dk  (michael.h.grant@gmail.com)

HOW TO RUN
Browsers block some features when a file is opened by double-click, so serve the folder:
  - Easiest: upload the whole folder to any web server (HTTPS) and open index.html.
  - Or locally:  python3 -m http.server 8000   then open http://localhost:8000
Once opened over HTTPS or localhost it installs as an app and then works fully offline.
No internet connection, accounts, tracking or external services are used.

CONTENTS
index.html  the app (English)      stonehenge-stars.js  star catalogue (Hipparcos via d3-celestial, BSD-3)        vendor/  three.js r160 (MIT licence)
images/     author's photographs     icons/, manifest.webmanifest, sw.js  (install + offline)

LICENCE
Text and code © Michael Grant, CC BY 4.0. Not an official English Heritage product.
